from ._pcsx2_interface import is_connected

__all__ = ["is_connected"]
